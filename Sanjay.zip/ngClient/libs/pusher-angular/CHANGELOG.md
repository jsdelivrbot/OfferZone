# Changelog

## 0.1.9

* Add option to skip calling $digest (@robwalkerco)