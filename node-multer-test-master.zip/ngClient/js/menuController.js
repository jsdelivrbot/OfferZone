myApp.controller("MenuCtrl", ['$scope', '$location', 'MenuFactory','Upload','$http',
    function($scope, $location, MenuFactory,Upload,$http) {
        $scope.success = false;
        $scope.dateRange = null;
        $scope.offer = {};
       


        $scope.menus = '';

        MenuFactory.getAllmenu().success(function(data) {
            console.log('ddd' + data);
            $scope.menus = data;
        });


        $scope.isActive = function(route) {
            return route === $location.path();
        }
        $scope.happyHrs = function($isHappyHr) {
            if ($isHappyHr == true) {
                $scope.showHappy = true;
                $scope.offer.isHappyHr=true;
            } else {
               $scope.offer.happyhour='';
               $scope.offer.isHappyHr=false;
                $scope.showHappy = false;
            }

        }

        $scope.onCategoryChange = function($selval) {
            if ($selval == 4) {
                $scope.showDays = true;
            } else {
                $scope.showDays = false;
            }
        }

        $scope.genPDF = function() {
            console.log('pdfgen');

            html2canvas(document.getElementById('print'), {
                onrendered: function(canvas) {

                    var data = canvas.toDataURL();
                    var docDefinition = {
                        content: [{
                            image: data,
                            width: 500,
                        }]
                    };
                    pdfMake.createPdf(docDefinition).download("Score_Details.pdf");
                }
            });

        }


        $scope.createMenu = function() {

            $scope.offer.file=($scope.image2.resized.dataURL);

            console.log($scope.image2.resized.dataURL);

//  var fd = new FormData();
           
//              fd.append("somefile", $scope.myFile);
//             return $http.post("/api/v1/single", fd, {
                
//                 headers: {'Content-Type': 'multipart/form-data' }
         
//             });

//  $http({  
//             method: 'POST',  
//             url:'http://localhost:8080/api/v1/single', 
//             headers: { 'Content-Type': undefined },  
//              transformRequest: function (data) {  
//                 var formData = new FormData();
               
//                formData.append("somefile", $scope.myFile);  
//                return formData;
                 
//             },
         
//             data: {  file: $scope.myFile }  
//         }).  
//         success(function (data, status, headers, config) {  
//             alert("success!");  
//         }).  
//         error(function (data, status, headers, config) {  
//             alert("failed!");  
//         }); 

// $http({
//    method: 'POST',
//    url: 'http://localhost:8080/api/v1/single',
//    headers: {
//       'Content-Type': 'multipart/form-data'
//    },
//    data: {
     
//       file: $scope.myFile
//    },
//    transformRequest: 'multipart/form-data'
// });



// var fd=new FormData();
// fd.append('somefile',$scope.myFile);

//   MenuFactory.create(fd).success(function(data){

//   });
//   Upload.upload({
//             url: 'http://localhost:3000/single',
//               //webAPI exposed to upload the file
//             data:{somefile:$scope.myFile} //pass file as data, should be user ng-model
//         }).then(function (resp) { //upload function returns a promise
//             console.log(resp);
//         }, function (resp) { //catch error
//              console.log(resp);
//         }, function (evt) { 
//              console.log(evt);
//         });
           
// $scope.menu.file=$scope.myFile;

// console.log($scope.menu);
//              
         
// console.log(($scope.offer.file));
var re=JSON.stringify($scope.offer);

MenuFactory.create(re).success(function(data){      
            

              });

        }
    }
]);