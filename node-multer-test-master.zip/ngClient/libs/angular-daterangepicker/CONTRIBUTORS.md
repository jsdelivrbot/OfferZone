# Contributors
Many thanks to following folks (ordered by date of contribution):

* [Ray Gerrard](https://github.com/raygerrard)
* [Will Wu](https://github.com/wubin1989)
* [Matt Traynham](https://github.com/mtraynham) (upgrade to Bootstrap Daterange picker 2.0)!
* [Wojciech Frącz](https://github.com/fracz)
* [Ondřej Plšek](https://github.com/ondrs)
* [Ryan Dale](https://github.com/RyanDale)
* [Steven](https://github.com/tcooc)
* [Moshe Bildner](https://github.com/mbildner)
* [klam](https://github.com/klam)
* [Marcelo Eduardo de Andrade Jr.](https://github.com/marcelinhov2)
* [Elmar](https://github.com/elm-)
* [Eric Byers](https://github.com/EricByers)
