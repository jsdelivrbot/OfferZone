# node-multer-test
Sample code for http://derpturkey.com/node-multipart-form-data-explained/
